import { NgModule } from "@angular/core";
import { FeedbackRoutingModule } from "./feedback-routing.module";
import { FeedbackComponent } from "./feedback.component";
import { StorageServiceModule} from 'angular-webstorage-service';
//import { MatButtonModule } from '@angular/material/button';
//import { MatInputModule } from '@angular/material/input';
//import { MatFormFieldModule } from '@angular/material/form-field';
@NgModule({
    declarations:[FeedbackComponent],
    imports:[FeedbackRoutingModule,StorageServiceModule,
    //MatButtonModule,
    //     MatFormFieldModule,
    //     MatInputModule,],
    //     exports: [
    //         MatButtonModule,
    //         MatFormFieldModule,
    //         MatInputModule,
           
          ],
    providers: []
    
})
export class FeedbackModule{

}
import { Component, VERSION,OnInit } from '@angular/core';
import * as products from "../files/sampleData.json";
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  
  public productList:{Image:any,Collection:string,Price:number,
   ProductTitle:string,StyleName:string,StyleNumber:number,
   NetQuantity:number,ProductCode:number,AvailableSizes:string}[]=products;
  constructor() { }

  ngOnInit() {
    
    this.productList = this.productList.sort((low, high) => low.Price - high.Price);
  }
  sort(event: any) {
    switch (event.target.value) {
      case "Low":
        {
          this.productList = this.productList.sort((low, high) => low.Price - high.Price);
          break;
        }

      case "High":
        {
          this.productList = this.productList.sort((low, high) => high.Price - low.Price);
          break;
        }

      case "ProductTitle":
        {
          this.productList = this.productList.sort(function (low, high) {
            if (low.ProductTitle < high.ProductTitle) {
              return -1;
            }
            else if (low.ProductTitle > high.ProductTitle) {
              return 1;
            }
            else {
              return 0;
            }
          })
          break;
        }

      default: {
        this.productList = this.productList.sort((low, high) => low.Price - high.Price);
        break;
      }

    }
    return this.productList;

  }

  onload(){
    this.productList.slice(1,12);
  }

}




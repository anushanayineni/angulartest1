import { NgModule } from "@angular/core";
import { ProductsRoutingModule } from "./products-routing.module";
import { ProductsComponent } from "./products.component";
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
@NgModule({
    declarations:[ProductsComponent],
    imports:[ProductsRoutingModule,InfiniteScrollModule],
    providers: []
    
})
export class ProductsModule{

}
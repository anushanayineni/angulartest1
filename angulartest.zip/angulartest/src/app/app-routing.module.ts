import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from "./login/login.component";
import { ProductsComponent} from "./products/products.component";
import { FeedbackComponent } from "./feedback/feedback.component";
const routes: Routes = [
    { path: "", component: LoginComponent },
    {
      path:"login",
      component: LoginComponent
    },
    {
      path:"products",
      component: ProductsComponent
    },
    {
      path:"feedback",
      component: FeedbackComponent
    },
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers:[]
})
export class AppRoutingModule { }

export const navigatableComponents = [
    LoginComponent,ProductsComponent,
    FeedbackComponent]
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { Button } from 'protractor';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  loginForm:FormGroup;
  submitted = false;
 
  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit() {
      this.loginForm = this.formBuilder.group({
          userName: ['', Validators.required],
         
          password: ['', [Validators.required, Validators.minLength(6)]]
      });
      
  }

  onSubmit() {
      this.submitted = true;

      // stop the process here if form is invalid
      if (this.loginForm.invalid) {
          return;
      }

     
    
  }
  login(){
    this.router.navigate([ '/products' ])
  }
  
}
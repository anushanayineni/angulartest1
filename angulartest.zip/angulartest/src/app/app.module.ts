import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { StorageServiceModule} from 'angular-webstorage-service';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

import { ReactiveFormsModule } from '@angular/forms'; 

import {ProductsComponent} from "./products/products.component";
import { LoginComponent } from './login/login.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { importType } from '@angular/compiler/src/output/output_ast';

@NgModule({
  declarations: [
    AppComponent,
   ProductsComponent,
   LoginComponent,
   FeedbackComponent
  ],
  imports: [
    BrowserModule,ReactiveFormsModule,AppRoutingModule,StorageServiceModule,InfiniteScrollModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
